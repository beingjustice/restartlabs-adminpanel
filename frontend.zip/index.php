<?php
/**
 * Root Index File
 * Redirects to frontend/index.html
 */

header('Location: frontend/index.html');
exit;
?>

