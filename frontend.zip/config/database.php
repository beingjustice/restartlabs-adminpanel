<?php
/**
 * Database Configuration
 * RestartLabs Admin Panel
 */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_NAME', 'rest_restartlabs');
define('DB_USER', 'rest_restartlabs');
define('DB_PASS', '3zMACJlRvI@FIPbf');
define('DB_CHARSET', 'utf8mb4');

// Create PDO connection
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>

